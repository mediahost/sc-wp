<?php

/**
 * File Type: Widgets
 */
require_once 'job_categories.php';
require_once 'top_recruiters.php';
require_once 'follower_social_network.php';
require_once 'pop_jobs.php';
require_once 'jobstack.php';
require_once 'contactinfo.php';
require_once 'sociallinks.php';
